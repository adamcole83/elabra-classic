<?
require_once('inc/init.php');
$session->logout();
redirect_to('login.php');
?>