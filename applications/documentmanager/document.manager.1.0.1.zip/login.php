<?
	require_once('inc/init.php');
	
	// check if user authenticated
	if($session->is_logged_in()) redirect_to('index.php');
	
	if(isset($_POST['username'])){
		
		// trim
		$username = trim($_POST['username']);
		$password = trim($_POST['password']);
		
		// authenticate user
		$found_user = User::authenticate($username, $password);
		if($found_user){
			$session->login($found_user);
			User::timestamp($found_user->id);
			redirect_to('index.php');
		}else{
			$message = "Invalid login!";
		}
	}
?>

<?php require_once('inc/template.head.php') ?>

<div id="contact-wrapper">
	<form method="post" action="<? $_SERVER['PHP_SELF'] ?>" id="contactform">
		<img src="img/lock.png" alt="lock" width="48px" height="48px" /><br />
		<h1>Secure Server</h1>
		<?php echo output_message($message); ?>
		
		<label for="name"><strong>Username:</strong></label>
		<input type="text" size="50" name="username" id="username" value="" class="required" />
		
		<label for="email"><strong>Password:</strong></label>
		<input type="password" size="50" name="password" id="password" value="" class="required email" />
	
		<input type="submit" name="submit" value="Login">
	</form>
</div>

<?php require_once('inc/template.foot.php') ?>