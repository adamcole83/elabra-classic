					<div style="clear:both;">&nbsp;</div>
				</div><!-- End contentContainer -->
			</div><!-- End middleContainer -->
			
		</div><!-- End mainContainer -->
		<div style="clear:both">&nbsp;</div>
		
		<!-- Footer & social media -->
		<? virtual('/includes/footer.php'); ?>
	</body>
</html>